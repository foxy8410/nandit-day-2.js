function myAlert(msg){
    if(confirm("are you sure want to display the message ???")){
        alert(msg);
    }
    else{
        alert("message not displayed as user canceled operation");
    }
}